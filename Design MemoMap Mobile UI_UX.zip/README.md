
  # Design MemoMap Mobile UI/UX

  This is a code bundle for Design MemoMap Mobile UI/UX. The original project is available at https://www.figma.com/design/zwoIElGUd6liT7xX2zOEC1/Design-MemoMap-Mobile-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  